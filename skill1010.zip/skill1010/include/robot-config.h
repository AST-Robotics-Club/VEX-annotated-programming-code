using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern controller Controller1;
extern motor BL;
extern motor BL2;
extern motor BR;
extern motor BR2;
extern motor SL;
extern motor SR;
extern motor I2;
extern motor I1;
extern bumper D;
extern bumper U;
extern signature v__BLUEBALL;
extern signature v__REDBALL;
extern signature v__FLAG;
extern signature v__SIG_4;
extern signature v__SIG_5;
extern signature v__SIG_6;
extern signature v__SIG_7;
extern vision v;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );