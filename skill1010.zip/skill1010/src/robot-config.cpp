#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
motor BL = motor(PORT1, ratio18_1, false);
motor BL2 = motor(PORT2, ratio18_1, false);
motor BR = motor(PORT3, ratio18_1, true);
motor BR2 = motor(PORT4, ratio18_1, true);
motor SL = motor(PORT5, ratio18_1, true);
motor SR = motor(PORT6, ratio18_1, false);
motor I2 = motor(PORT7, ratio6_1, false);
motor I1 = motor(PORT8, ratio6_1, false);
bumper D = bumper(Brain.ThreeWirePort.H);
bumper U = bumper(Brain.ThreeWirePort.G);
/*vex-vision-config:begin*/
signature v__BLUEBALL = signature (1, -3485, -1877, -2681, 7245, 14799, 11022, 2.5, 0);
signature v__REDBALL = signature (2, 7127, 12677, 9902, -837, 565, -136, 2.5, 0);
signature v__FLAG = signature (3, -4969, -4551, -4760, -5599, -4789, -5194, 2.5, 0);
vision v = vision (PORT20, 50, v__BLUEBALL, v__REDBALL, v__FLAG);
/*vex-vision-config:end*/

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}