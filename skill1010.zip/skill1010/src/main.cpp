/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// BL                   motor         1               
// BL2                  motor         2               
// BR                   motor         3               
// BR2                  motor         4               
// SL                   motor         5               
// SR                   motor         6               
// I2                   motor         7               
// I1                   motor         8               
// D                    bumper        H               
// U                    bumper        G               
// v                    vision        20              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}
/*
int count;
int n;
if (Controller1.pressing)
{
  n=1;
  n++
}

*/

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
/*
void slide(int deg, int tf, double p, int s)
{
  while((fabs(BR2.position(degrees)))<deg)
  {
    BL.spin(fwd,tf,pct);
    BL2.spin(fwd,-tf*p,pct);
    BR.spin(fwd,-tf,pct);
    BR2.spin(fwd,tf*p,pct);
  }
  if (s == 1)
  {
    BL.stop(brakeType ::brake);
    BL2.stop(brakeType ::brake);
    BR.stop(brakeType ::brake);
    BR2.stop(brakeType ::brake);
  }
  else if (s==0)
  {
    BL.spin(fwd,0,velocityUnits::pct);
    BL2.spin(fwd,0,velocityUnits::pct);
    BR.spin(fwd,0,velocityUnits::pct);
    BR2.spin(fwd,0,velocityUnits::pct);
  }
  else if (s==2)
  {

  }
  else
  {
    BL.spin(fwd,0,velocityUnits::pct);
    BL2.spin(fwd,0,velocityUnits::pct);
    BR.spin(fwd,0,velocityUnits::pct);
    BR2.spin(fwd,0,velocityUnits::pct);
  }
}*/
void control (float x, float rotate)
{
  
    rotate=Controller1.Axis4.value();
    x=Controller1.Axis3.value();
    if(Controller1.ButtonL1.pressing())
    {

    BL.spin(directionType::fwd, 100+rotate, velocityUnits::pct);
    BL2.spin(directionType::fwd, 100+rotate, velocityUnits::pct);
    BR.spin(directionType::fwd, 100-rotate, velocityUnits::pct);
    BR2.spin(directionType::fwd, 100-rotate, velocityUnits::pct);
    }
    else if(Controller1.ButtonL2.pressing())
    {
    BL.spin(directionType::fwd, -100+rotate, velocityUnits::pct);
    BL2.spin(directionType::fwd, -100+rotate, velocityUnits::pct);
    BR.spin(directionType::fwd, -100-rotate, velocityUnits::pct);
    BR2.spin(directionType::fwd, -100-rotate, velocityUnits::pct);
    }
    else
    {
    BL.spin(directionType::fwd, x+rotate, velocityUnits::pct);
    BL2.spin(directionType::fwd, x+rotate, velocityUnits::pct);
    BR.spin(directionType::fwd, x-rotate, velocityUnits::pct);
    BR2.spin(directionType::fwd, x-rotate, velocityUnits::pct);
    }
}
void Moove (float x, float y, float rotate){
    
    y=Controller1.Axis4.value();
    x=Controller1.Axis3.value();
    rotate=Controller1.Axis1.value()*0.8;
    if(x!=0||rotate!=0)
    {
    BL.spin(directionType::fwd, x+rotate, velocityUnits::pct);
    BL2.spin(directionType::fwd,x+rotate, velocityUnits::pct);
    BR.spin(directionType::fwd, x-rotate, velocityUnits::pct);
    BR2.spin(directionType::fwd, x-rotate, velocityUnits::pct);
    }
    else
    {
      BL.stop(coast);
      BL2.stop(coast);
      BR.stop(coast);
      BR2.stop(coast);
    }
    
}
void move (int deg, int Lpower, int Rpower, int s)
{
  BL.resetPosition();
  BR.resetPosition();
  BL2.resetPosition();
  BR2.resetPosition();
  while((fabs(BL2.position(degrees))+fabs(BR2.position(degrees)))/2<deg)
  {
    BL.spin(fwd,Lpower,pct);
    BL2.spin(fwd,Lpower,pct);
    BR.spin(fwd,Rpower,pct);
    BR2.spin(fwd,Rpower,pct);
  }
  if (s == 0)
  {
    BL.spin(fwd,0,velocityUnits::pct);
    BL2.spin(fwd,0,velocityUnits::pct);
    BR.spin(fwd,0,velocityUnits::pct);
    BR2.spin(fwd,0,velocityUnits::pct);
  }
  else if (s==1)
  {
    BL.stop(brakeType ::brake);
    BL2.stop(brakeType ::brake);
    BR.stop(brakeType ::brake);
    BR2.stop(brakeType ::brake);

  }
  else if (s==2)
  {

  }
  else
  {
    BL.spin(fwd,0,velocityUnits::pct);
    BL2.spin(fwd,0,velocityUnits::pct);
    BR.spin(fwd,0,velocityUnits::pct);
    BR2.spin(fwd,0,velocityUnits::pct);
  }
}

void Time (int sec, int Lpower, int Rpower, int s)
{
    BL.spin(fwd,Lpower,pct);
    BL2.spin(fwd,Lpower,pct);
    BR.spin(fwd,Rpower,pct);
    BR2.spin(fwd,Rpower,pct);
  wait(sec,msec);
  if (s == 1)
  {
    BL.stop(brakeType ::brake);
    BL2.stop(brakeType ::brake);
    BR.stop(brakeType ::brake);
    BR2.stop(brakeType ::brake);
  }
  else if (s==0)
  {
    BL.stop(brakeType ::coast);
    BL2.stop(brakeType ::coast);
    BR.stop(brakeType ::coast);
    BR2.stop(brakeType ::coast);
    
  }
  else
  {
    BL.spin(fwd,0,velocityUnits::pct);
    BL2.spin(fwd,0,velocityUnits::pct);
    BR.spin(fwd,0,velocityUnits::pct);
    BR2.spin(fwd,0,velocityUnits::pct);
  }
}
void intake(double pwr){
  if(pwr != 0)
  {
    SL.spin(fwd,pwr,pct);
    SR.spin(fwd,pwr,pct);
  }
  else
  {
    SL.stop(brake);
    SR.stop(brake);
  }
}


void autonomous(void) 
{
  //*
  SL.spin(fwd,100,pct);
  SR.spin(fwd,100,pct);
  I2.spin(fwd,70,pct);
  I1.stop(brake);
  move(230,40,40,1);
  wait(300,msec);
  move(410,0,50,1);
  wait(100,msec);
  intake(0);
  I2.stop(brake);
  Time(800,70,70,1);
  wait(100,msec);
  //first ball
  I1.spin(fwd,100,pct);
  wait(800,msec);
  I1.stop(brake);
  intake(-100);
  move(280,-5,-85,1);
  intake(100);
  I2.spin(fwd,60,pct);
  wait(100,msec);
  Time(1000,50,48,1);
  Time(300,60,30,1);
  Time(1200,50,50,1);
  intake(0);
  I2.stop(brake);
  //second ball
  I1.spin(fwd,100,pct);
  wait(800,msec);
  I1.stop(brake);
  move(500,-40,-40,1);
  move(110,0,-50,1);
  intake(100);
  wait(100,msec);
  I2.spin(fwd,40,pct);
  move(900,40,40,1);
  move(130,0,50,1);
  Time(300,50,45,1);
  Time(2200,45,42,0);
  intake(0);
  I2.stop(brake);
  Time(700,-15,70,1);
  Time(300,50,50,1);
  //third ball
  I1.spin(fwd,100,pct);
  wait(800,msec);
  I1.stop(brake);
  intake(-100);
  move(50,-40,-40,1);
  intake(0);
  I2.spin(fwd,100,pct);
  move(250,40,-40,1);
  Time(1400,80,80,1);
  I2.stop(brake);
  Time(200,40,40,1);
  //fourth
  I1.spin(fwd,100,pct);
  wait(700,msec);
  I1.stop(brake);
  move(200,-40,-40,1);
  I2.spin(fwd,100,pct);
  intake(100);
  move(90,0,-50,1);
  move(500,50,50,1);
  move(100,0,50,1);
  Time(1800,65,65,0);
  intake(0);
  I2.stop(brake);
  Time(300,40,40,0);
  //fif
  I1.spin(fwd,100,pct);
  wait(500,msec);
  I1.stop(brake);
  intake(-100);
  move(80,-40,-40,1);
  Time(800,0,-75,1);
  Time(500,-40,-40,0);
  wait(200,msec);
  move(450,40,40,1);
  wait(200,msec);
  move(255,0,50,1);
  wait(200,msec);
  intake(100);
  I2.spin(fwd,60,pct);
  Time(700,60,60,1);
  wait(300,msec);
  intake(0);
  Time(300,50,-60,1);
  Time(1700,70,70,1);
  I2.stop(brake);
  //sixth
  I1.spin(fwd,100,pct);
  wait(1000,msec);
  I1.stop(brake);
  move(550,-40,-40,1);
  move(110,0,-50,1);
  intake(100);
  wait(100,msec);
  move(750,40,40,1);
  move(125,0,50,1);
  I2.spin(fwd,100,pct);
  Time(2200,50,47,1);
  Time(300,50,40,1);
  //seventh
  intake(0);
  I2.stop(brake);
  I1.spin(fwd,100,pct);
  wait(800,msec);
  I1.stop(brake);
  intake(-100);
  I2.spin(fwd,100,pct);
  move(50,-40,-40,1);
  move(170,40,-40,1);
  intake(0);
  Time(1500,80,80,1);
  Time(200,40,40,1);
  I2.stop(brake);
  //eighth
  I1.spin(fwd,100,pct);
  wait(500,msec);
  I1.stop(brake);
  move(400,10,-50,1);
  Time(700,-40,-40,1);
  wait(200,msec);
  move(500,40,40,1);
  wait(200,msec);
  move(125,0,40,1);
  wait(200,msec);
  intake(100);
  I2.spin(fwd,100,pct);
  move(350,40,40,1);
  wait(200,msec);
  move(130,50,0,1);
  wait(200,msec);
  Time(950,45,45,0);
  intake(0);
  move(50,-30,-30,1);
  wait(200,msec);
  move(60,0,30,1);
  I2.stop(brake);
  I1.spin(fwd,65,pct);
  wait(800,msec);
  I1.stop(brake);
}
void usercontrol(void) {
      
  }

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
